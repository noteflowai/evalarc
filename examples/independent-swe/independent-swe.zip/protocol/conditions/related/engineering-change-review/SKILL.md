---
name: engineering-change-review
description: Diagnose and repair a reported repository defect while preserving existing behavior and checking the delivered change.
---

# Engineering change review

Work from the issue, the actual repository and observable behavior.

1. Read the reported behavior and locate the implementation and relevant existing tests.
   Separate the expected behavior from guesses about the cause. Check the current
   source before relying on a remembered implementation.
2. Reproduce a focused example when practical. Record the command and its result.
   Distinguish a failing behavior from an unavailable dependency or a command that
   never executed the test.
3. Trace the values and control flow that produce the result. Check callers and
   neighboring branches before choosing where to change the implementation.
4. Make a focused source change that preserves the public interface and unrelated
   behavior. Avoid replacing the computation with a constant, suppressing exceptions
   broadly, or weakening tests to make the run appear successful.
5. Run the relevant existing tests and check nearby behavior that the change could
   affect. A passing example does not establish that every regression check passed.
   Keep failures and skipped or unavailable checks visible.
6. Inspect the final diff. Remove accidental edits and confirm that the delivered
   files contain the intended change. Report what changed, what was actually checked
   and what remains uncertain.

Use the provided tools within their allowed workspace. Do not fetch a published
solution, alter the evaluator, or claim that unexecuted checks passed.
