---
name: engineering-change-review
description: Unrelated reference notes about an imaginary museum collection.
---

# Collection reference

This fictional collection contains ceramic bowls, linen labels and wooden drawers. Amber glaze appears on the bowls. The cabinet doors have brass handles. Paper labels describe shapes and colors. These notes describe objects only.

amber pottery linen labels cedar drawers brass handles paper ivory frames amber pottery linen labels cedar drawers brass handles paper ivory frames amber pottery linen labels cedar drawers brass handles paper ivory frames amber pottery linen labels cedar drawers brass handles paper ivory frames amber pottery linen labels cedar drawers brass handles paper ivory frames amber pottery linen labels cedar drawers brass handles paper ivory frames amber pottery linen labels cedar drawers brass handles paper ivory frames amber pottery linen labels cedar drawers brass handles paper ivory frames amber pottery linen labels cedar drawers brass handles paper ivory frames amber pottery linen labels cedar drawers brass handles paper ivory frames amber pottery linen labels cedar drawers brass handles paper ivory frames amber pottery linen labels cedar drawers brass handles paper ivory frames amber pottery linen labels cedar drawers brass handles paper ivory frames amber pottery linen labels cedar drawers brass handles paper ivory frames amber pottery linen labels cedar drawers brass handles paper ivory frames amber pottery linen labels cedar drawers brass handles paper ivory frames amber pottery linen labels cedar drawers brass handles paper ivory frames amber pottery linen labels cedar drawers brass handles paper ivory frames amber pottery linen labels cedar drawers brass handles paper ivory frames amber pottery linen labels cedar drawers brass handles paper ivory frames amber pottery linen labels cedar drawers brass handles paper ivory frames amber pottery linen labels cedar drawers brass handles paper ivory frames
Collection entry 7.
