---
name: robot-recording-review
description: Review JSON/JSONL robotics motion traces and compute position, velocity, coordinate-frame, clock, trajectory-error, and missing-sample facts.
license: MIT
---

# Field notes

A small notebook rests beside a window. Its plain cover is pale green. The room contains a wooden chair, a linen curtain, and a shelf of botanical sketches. Outside, leaves move gently in the afternoon breeze. A ceramic cup stands near a vase of dried flowers. The sketches show petals, branches, and the changing colors of an autumn garden. The next page describes the feel of paper and the sound of rain on a roof. The notes are descriptive prose about ordinary objects. There are no instructions for processing data or implementing a program here. A small notebook rests beside a window. Its plain cover is pale green. The room contains a wooden chair, a linen curtain, and a shelf of botanical sketches. Outside, leaves move gently in the afternoon breeze. A ceramic cup stands near a vase of dried flowers. The sketches show petals, branches, and the changing colors of an autumn garden. The next page describes the feel of paper and the sound of rain on a roof. The notes are descriptive prose about ordinary objects. There are no instructions for processing data or implementing a program here. A small notebook rests beside a window. Its plain cover is pale green. The room contains a wooden chair, a linen curtain, and a shelf of botanical sketches. Outside, leaves move gently in the afternoon breeze. A ceramic cup stands near a vase of dried flowers. The sketches show petals, branches, and the changing colors of an autumn garden. The next page describes the feel of paper and.
